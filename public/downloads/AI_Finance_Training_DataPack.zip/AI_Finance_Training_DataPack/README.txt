AI for the Finance Function - Training Data Pack
=================================================
Simulated training data. One connected quarter (Q2 2026). Safe to use
with any AI tool - nothing in these files is real.

Files
  Data_Case01_Admin_Expense_Ledger.xlsx    Case 1  Excel - split (VBA, then Copilot)
  Data_Case02_Accrual_Consolidation.xlsx   Case 2  Excel - quarter-end accruals
  Data_Case03_Invoice_Register.xlsx        Case 3  Excel - AP register cleanup
  Data_Case04_Budget_vs_Actuals.xlsx       Case 4  Excel - variance dashboard
  Data_Case05_Reporting_Pack_Inputs.xlsx   Case 5  Word  - the quarterly memo
                                           Case 6  PowerPoint - uses your Case 5 memo
  Data_Case07_Investment_FV_Rollforward.xlsx  Case 7  Excel+Word - take-home

Before the session
  1. Copy these files into your OneDrive (AutoSave ON).
  2. Check the Copilot button is lit in Excel, Word and PowerPoint.
  3. Case exercises are on the training site - work from there.

All numbers regenerate from a fixed random seed, so your self-check
totals will match the printed expected results exactly.
